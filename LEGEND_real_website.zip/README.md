# LEGEND Website
Premium responsive smartphone website using HTML/CSS/JavaScript with a C++ Crow backend.

Frontend: open `index.html`.

Backend:
1. Install CrowCpp.
2. Put all files in one folder.
3. Compile: `g++ -std=c++17 main.cpp -o legend_server -pthread`
4. Run: `./legend_server`
5. Visit `http://localhost:18080`

API:
- `/api/health`
- `/api/products`

The UI is ready to connect to real authentication, database, inventory, checkout and payment APIs.