// LEGEND C++ backend using Crow.
// Install CrowCpp, then compile with C++17:
// g++ -std=c++17 main.cpp -o legend_server -pthread
// Run: ./legend_server
// Open: http://localhost:18080

#include <crow.h>
#include <fstream>
#include <sstream>

std::string file(const std::string& p){
    std::ifstream f(p,std::ios::binary);
    std::ostringstream s; s<<f.rdbuf(); return s.str();
}
int main(){
    crow::SimpleApp app;
    CROW_ROUTE(app,"/")([]{
        auto r=crow::response(file("index.html"));
        r.set_header("Content-Type","text/html; charset=utf-8"); return r;
    });
    CROW_ROUTE(app,"/styles.css")([]{
        auto r=crow::response(file("styles.css"));
        r.set_header("Content-Type","text/css"); return r;
    });
    CROW_ROUTE(app,"/app.js")([]{
        auto r=crow::response(file("app.js"));
        r.set_header("Content-Type","application/javascript"); return r;
    });
    CROW_ROUTE(app,"/api/health")([]{
        crow::json::wvalue x; x["brand"]="LEGEND"; x["status"]="online"; return crow::response(x);
    });
    CROW_ROUTE(app,"/api/products")([]{
        crow::json::wvalue x;
        x["x1"]["name"]="LEGEND X1"; x["x1"]["price"]="₹10,000 – ₹19,000";
        x["y1"]["name"]="LEGEND Y1"; x["y1"]["price"]="₹30,000 – ₹50,000";
        x["z1"]["name"]="LEGEND Z1"; x["z1"]["price"]="₹80,000 – ₹1,00,000";
        return crow::response(x);
    });
    app.port(18080).multithreaded().run();
}